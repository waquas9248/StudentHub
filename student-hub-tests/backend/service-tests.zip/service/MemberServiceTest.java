package com.app.studenthub.service;

import com.app.studenthub.model.Member;
import com.app.studenthub.model.User;
import com.app.studenthub.model.Group;
import com.app.studenthub.repository.MemberRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class MemberServiceTest {

    @MockBean
    private MemberRepository memberRepository;

    @Autowired
    private MemberService memberService;

    @Test
    void testGetAllMembers() {
        // Given
        Member member1 = new Member();
        Member member2 = new Member();
        when(memberRepository.findAll()).thenReturn(Arrays.asList(member1, member2));

        // When
        List<Member> members = memberService.getAllMembers();

        // Then
        assertEquals(2, members.size());
        verify(memberRepository, times(1)).findAll();
    }

    @Test
    void testGetMemberById() {
        // Given
        Long id = 1L;
        Member member = new Member();
        when(memberRepository.findById(id)).thenReturn(Optional.of(member));

        // When
        Optional<Member> result = memberService.getMemberById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(member, result.get());
        verify(memberRepository, times(1)).findById(id);
    }

    @Test
    void testGetMembersByUserId() {
        // Given
        Long userId = 1L;
        Member member1 = new Member();
        Member member2 = new Member();
        when(memberRepository.findAllByUser_Id(userId)).thenReturn(Arrays.asList(member1, member2));

        // When
        List<Member> members = memberService.getMembersByUserId(userId);

        // Then
        assertEquals(2, members.size());
        verify(memberRepository, times(1)).findAllByUser_Id(userId);
    }

    @Test
    void testGetMembersByGroupId() {
        // Given
        Long groupId = 1L;
        Member member1 = new Member();
        Member member2 = new Member();
        when(memberRepository.findAllByGroup_Id(groupId)).thenReturn(Arrays.asList(member1, member2));

        // When
        List<Member> members = memberService.getMembersByGroupId(groupId);

        // Then
        assertEquals(2, members.size());
        verify(memberRepository, times(1)).findAllByGroup_Id(groupId);
    }

    @Test
    void testCreateMember() {
        // Given
        Member member = new Member();
        when(memberRepository.save(member)).thenReturn(member);

        // When
        Member createdMember = memberService.createMember(member);

        // Then
        assertNotNull(createdMember);
        verify(memberRepository, times(1)).save(member);
    }

    @Test
    void testUpdateMember() {
        // Given
        Long id = 1L;
        Member existingMember = new Member();
        User oldUser = new User();
        Group oldGroup = new Group();
        existingMember.setUser(oldUser);
        existingMember.setGroup(oldGroup);

        Member updatedMemberDetails = new Member();
        User newUser = new User();
        Group newGroup = new Group();
        updatedMemberDetails.setUser(newUser);
        updatedMemberDetails.setGroup(newGroup);

        when(memberRepository.findById(id)).thenReturn(Optional.of(existingMember));
        when(memberRepository.save(existingMember)).thenReturn(existingMember);

        // When
        Member updatedMember = memberService.updateMember(id, updatedMemberDetails);

        // Then
        assertNotNull(updatedMember);
        assertEquals(newUser, updatedMember.getUser());
        assertEquals(newGroup, updatedMember.getGroup());
        verify(memberRepository, times(1)).findById(id);
        verify(memberRepository, times(1)).save(existingMember);
    }

    @Test
    void testDeleteMember() {
        // Given
        Long id = 1L;

        // When
        memberService.deleteMember(id);

        // Then
        verify(memberRepository, times(1)).deleteById(id);
    }
}
