package com.app.studenthub.service;

import com.app.studenthub.model.Location;
import com.app.studenthub.repository.LocationRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class LocationServiceTest {

    @MockBean
    private LocationRepository locationRepository;

    @Autowired
    private LocationService locationService;

    @Test
    void testFindAllLocations() {
        // Given
        Location location1 = new Location();
        Location location2 = new Location();
        when(locationRepository.findAll()).thenReturn(Arrays.asList(location1, location2));

        // When
        List<Location> locations = locationService.findAllLocations();

        // Then
        assertEquals(2, locations.size());
        verify(locationRepository, times(1)).findAll();
    }

    @Test
    void testFindLocationById() {
        // Given
        Long id = 1L;
        Location location = new Location();
        when(locationRepository.findById(id)).thenReturn(Optional.of(location));

        // When
        Optional<Location> result = locationService.findLocationById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(location, result.get());
        verify(locationRepository, times(1)).findById(id);
    }

    @Test
    void testSaveLocation() {
        // Given
        Location location = new Location();
        when(locationRepository.save(location)).thenReturn(location);

        // When
        Location savedLocation = locationService.saveLocation(location);

        // Then
        assertNotNull(savedLocation);
        assertEquals(location, savedLocation);
        verify(locationRepository, times(1)).save(location);
    }

    @Test
    void testUpdateLocation() {
        // Given
        Long id = 1L;
        Location existingLocation = new Location();
        existingLocation.setStreetAddress("Old Address");

        Location updatedLocationDetails = new Location();
        updatedLocationDetails.setStreetAddress("New Address");

        when(locationRepository.findById(id)).thenReturn(Optional.of(existingLocation));
        when(locationRepository.save(existingLocation)).thenReturn(existingLocation);

        // When
        Location updatedLocation = locationService.updateLocation(id, updatedLocationDetails);

        // Then
        assertNotNull(updatedLocation);
        assertEquals("New Address", updatedLocation.getStreetAddress());
        verify(locationRepository, times(1)).findById(id);
        verify(locationRepository, times(1)).save(existingLocation);
    }

    @Test
    void testDeleteLocation() {
        // Given
        Long id = 1L;

        // When
        locationService.deleteLocation(id);

        // Then
        verify(locationRepository, times(1)).deleteById(id);
    }
}
