package com.app.studenthub.service;

import com.app.studenthub.model.Event;
import com.app.studenthub.repository.EventRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class EventServiceTest {

    @MockBean
    private EventRepository eventRepository;

    @Autowired
    private EventService eventService;

    @Test
    void testGetAllEvents() {
        // Given
        Event event1 = new Event();
        Event event2 = new Event();
        when(eventRepository.findAll()).thenReturn(Arrays.asList(event1, event2));

        // When
        List<Event> events = eventService.getAllEvents();

        // Then
        assertEquals(2, events.size());
        verify(eventRepository, times(1)).findAll();
    }

    @Test
    void testGetEventById() {
        // Given
        Event event = new Event();
        Long id = 1L;
        when(eventRepository.findById(id)).thenReturn(Optional.of(event));

        // When
        Optional<Event> result = eventService.getEventById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(event, result.get());
        verify(eventRepository, times(1)).findById(id);
    }

    @Test
    void testGetEventByName() {
        // Given
        Event event = new Event();
        String name = "Test Event";
        when(eventRepository.findByName(name)).thenReturn(Optional.of(event));

        // When
        Optional<Event> result = eventService.getEventByName(name);

        // Then
        assertTrue(result.isPresent());
        assertEquals(event, result.get());
        verify(eventRepository, times(1)).findByName(name);
    }

    @Test
    void testGetAllEventsByEventStartTime() {
        // Given
        LocalDateTime startTime = LocalDateTime.now();
        Event event1 = new Event();
        Event event2 = new Event();
        List<Event> events = Arrays.asList(event1, event2);
        when(eventRepository.findAllByEventStartTimeGreaterThanEqual(startTime)).thenReturn(events);

        // When
        List<Event> result = eventService.getAllEventsByEventStartTime(startTime);

        // Then
        assertNotNull(result);
        assertEquals(events.size(), result.size());
        verify(eventRepository, times(1)).findAllByEventStartTimeGreaterThanEqual(startTime);
    }

    @Test
    void testGetAllEventsByEventEndTime() {
        // Given
        LocalDateTime endTime = LocalDateTime.now().plusHours(1);
        Event event1 = new Event();
        Event event2 = new Event();
        List<Event> events = Arrays.asList(event1, event2);
        when(eventRepository.findAllByEventEndTimeGreaterThanCurrentTimeAndEventEndTimeLessThanEqual(endTime)).thenReturn(events);

        // When
        List<Event> result = eventService.getAllEventsByEventEndTime(endTime);

        // Then
        assertNotNull(result);
        assertEquals(events.size(), result.size());
        verify(eventRepository, times(1)).findAllByEventEndTimeGreaterThanCurrentTimeAndEventEndTimeLessThanEqual(endTime);
    }

    @Test
    void testCreateEvent() {
        // Given
        Event event = new Event();
        when(eventRepository.save(event)).thenReturn(event);

        // When
        Event createdEvent = eventService.createEvent(event);

        // Then
        assertNotNull(createdEvent);
        verify(eventRepository, times(1)).save(event);
    }

    @Test
    void testUpdateEvent() {
        // Given
        Long id = 1L;
        Event existingEvent = new Event();
        existingEvent.setName("Old Name");
        existingEvent.setDescription("Old Description");
        
        Event updatedEventDetails = new Event();
        updatedEventDetails.setName("New Name");
        updatedEventDetails.setDescription("New Description");

        when(eventRepository.findById(id)).thenReturn(Optional.of(existingEvent));
        when(eventRepository.save(existingEvent)).thenReturn(existingEvent);

        // When
        Event updatedEvent = eventService.updateEvent(id, updatedEventDetails);

        // Then
        assertNotNull(updatedEvent);
        assertEquals("New Name", updatedEvent.getName());
        assertEquals("New Description", updatedEvent.getDescription());
        verify(eventRepository, times(1)).findById(id);
        verify(eventRepository, times(1)).save(existingEvent);
    }

    @Test
    void testDeleteEvent() {
        // Given
        Long id = 1L;

        // When
        eventService.deleteEvent(id);

        // Then
        verify(eventRepository, times(1)).deleteById(id);
    }
}
