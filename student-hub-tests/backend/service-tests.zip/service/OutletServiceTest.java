package com.app.studenthub.service;

import com.app.studenthub.model.Outlet;
import com.app.studenthub.repository.OutletRepository;
import com.app.studenthub.util.OutletType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class OutletServiceTest {

    @MockBean
    private OutletRepository outletRepository;

    @Autowired
    private OutletService outletService;

    @Test
    void testGetAllOutlets() {
        // Given
        Outlet outlet1 = new Outlet();
        Outlet outlet2 = new Outlet();
        when(outletRepository.findAll()).thenReturn(Arrays.asList(outlet1, outlet2));

        // When
        List<Outlet> outlets = outletService.getAllOutlets();

        // Then
        assertEquals(2, outlets.size());
        verify(outletRepository, times(1)).findAll();
    }

    @Test
    void testGetOutletByName() {
        // Given
        String name = "Test Outlet";
        Outlet outlet = new Outlet();
        when(outletRepository.findByName(name)).thenReturn(Optional.of(outlet));

        // When
        Optional<Outlet> result = outletService.getOutletByName(name);

        // Then
        assertTrue(result.isPresent());
        assertEquals(outlet, result.get());
        verify(outletRepository, times(1)).findByName(name);
    }

    @Test
    void testGetOutletsByRating() {
        // Given
        Float rating = 4.0f;
        Outlet outlet1 = new Outlet();
        Outlet outlet2 = new Outlet();
        when(outletRepository.findAllByRatingGreaterThanEqual(rating)).thenReturn(Arrays.asList(outlet1, outlet2));

        // When
        List<Outlet> outlets = outletService.getOutletsByRating(rating);

        // Then
        assertEquals(2, outlets.size());
        verify(outletRepository, times(1)).findAllByRatingGreaterThanEqual(rating);
    }

    @Test
    void testGetAllOutletsByType() {
        // Given
        OutletType type = OutletType.FOOD;
        Outlet outlet1 = new Outlet();
        Outlet outlet2 = new Outlet();
        when(outletRepository.findAllByOutletType(type)).thenReturn(Arrays.asList(outlet1, outlet2));

        // When
        List<Outlet> outlets = outletService.getAllOutletsByType(type);

        // Then
        assertEquals(2, outlets.size());
        verify(outletRepository, times(1)).findAllByOutletType(type);
    }

    @Test
    void testGetOutletById() {
        // Given
        Long id = 1L;
        Outlet outlet = new Outlet();
        when(outletRepository.findById(id)).thenReturn(Optional.of(outlet));

        // When
        Optional<Outlet> result = outletService.getOutletById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(outlet, result.get());
        verify(outletRepository, times(1)).findById(id);
    }

    @Test
    void testCreateOutlet() {
        // Given
        Outlet outlet = new Outlet();
        when(outletRepository.save(outlet)).thenReturn(outlet);

        // When
        Outlet createdOutlet = outletService.createOutlet(outlet);

        // Then
        assertNotNull(createdOutlet);
        assertEquals(outlet, createdOutlet);
        verify(outletRepository, times(1)).save(outlet);
    }

    @Test
    void testUpdateOutlet() {
        // Given
        Long id = 1L;
        Outlet existingOutlet = new Outlet();
        existingOutlet.setName("Old Name");
        existingOutlet.setOutletType(OutletType.FOOD);

        Outlet updatedOutletDetails = new Outlet();
        updatedOutletDetails.setName("New Name");
        updatedOutletDetails.setOutletType(OutletType.DRINKS);

        when(outletRepository.findById(id)).thenReturn(Optional.of(existingOutlet));
        when(outletRepository.save(existingOutlet)).thenReturn(existingOutlet);

        // When
        Outlet updatedOutlet = outletService.updateOutlet(id, updatedOutletDetails);

        // Then
        assertNotNull(updatedOutlet);
        assertEquals("New Name", updatedOutlet.getName());
        assertEquals(OutletType.DRINKS, updatedOutlet.getOutletType());
        verify(outletRepository, times(1)).findById(id);
        verify(outletRepository, times(1)).save(existingOutlet);
    }

    @Test
    void testDeleteOutlet() {
        // Given
        Long id = 1L;

        // When
        outletService.deleteOutlet(id);

        // Then
        verify(outletRepository, times(1)).deleteById(id);
    }
}
