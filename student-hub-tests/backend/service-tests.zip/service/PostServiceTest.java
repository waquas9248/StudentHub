package com.app.studenthub.service;

import com.app.studenthub.model.Post;
import com.app.studenthub.model.User;
import com.app.studenthub.model.Group;
import com.app.studenthub.repository.PostRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class PostServiceTest {

    @MockBean
    private PostRepository postRepository;

    @Autowired
    private PostService postService;

    @Test
    void testGetAllPosts() {
        // Given
        Post post1 = new Post();
        Post post2 = new Post();
        when(postRepository.findAll()).thenReturn(Arrays.asList(post1, post2));

        // When
        List<Post> posts = postService.getAllPosts();

        // Then
        assertEquals(2, posts.size());
        verify(postRepository, times(1)).findAll();
    }

    @Test
    void testGetPostById() {
        // Given
        Long id = 1L;
        Post post = new Post();
        when(postRepository.findById(id)).thenReturn(Optional.of(post));

        // When
        Optional<Post> result = postService.getPostById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(post, result.get());
        verify(postRepository, times(1)).findById(id);
    }

    @Test
    void testGetAllPostsByUser() {
        // Given
        Long userId = 1L;
        Post post1 = new Post();
        Post post2 = new Post();
        when(postRepository.findAllByUser_Id(userId)).thenReturn(Arrays.asList(post1, post2));

        // When
        List<Post> posts = postService.getAllPostsByUser(userId);

        // Then
        assertEquals(2, posts.size());
        verify(postRepository, times(1)).findAllByUser_Id(userId);
    }

    @Test
    void testGetAllPostsByGroup() {
        // Given
        Long groupId = 1L;
        Post post1 = new Post();
        Post post2 = new Post();
        when(postRepository.findAllByGroup_Id(groupId)).thenReturn(Arrays.asList(post1, post2));

        // When
        List<Post> posts = postService.getAllPostsByGroup(groupId);

        // Then
        assertEquals(2, posts.size());
        verify(postRepository, times(1)).findAllByGroup_Id(groupId);
    }

    @Test
    void testCreatePost() {
        // Given
        Post post = new Post();
        when(postRepository.save(post)).thenReturn(post);

        // When
        Post createdPost = postService.createPost(post);

        // Then
        assertNotNull(createdPost);
        assertEquals(post, createdPost);
        verify(postRepository, times(1)).save(post);
    }

    @Test
    void testUpdatePost() {
        // Given
        Long id = 1L;
        Post existingPost = new Post();
        existingPost.setTitle("Old Title");
        existingPost.setBody("Old Body");

        Post updatedPostDetails = new Post();
        updatedPostDetails.setTitle("New Title");
        updatedPostDetails.setBody("New Body");
        User user = new User();
        Group group = new Group();
        updatedPostDetails.setUser(user);
        updatedPostDetails.setGroup(group);
        updatedPostDetails.setStatus("New Status");
        updatedPostDetails.setCreatedAt(LocalDateTime.now());

        when(postRepository.findById(id)).thenReturn(Optional.of(existingPost));
        when(postRepository.save(existingPost)).thenReturn(existingPost);

        // When
        Post updatedPost = postService.updatePost(id, updatedPostDetails);

        // Then
        assertNotNull(updatedPost);
        assertEquals("New Title", updatedPost.getTitle());
        assertEquals("New Body", updatedPost.getBody());
        assertEquals(user, updatedPost.getUser());
        assertEquals(group, updatedPost.getGroup());
        assertEquals("New Status", updatedPost.getStatus());
        assertNotNull(updatedPost.getCreatedAt());
        verify(postRepository, times(1)).findById(id);
        verify(postRepository, times(1)).save(existingPost);
    }

    @Test
    void testDeletePost() {
        // Given
        Long id = 1L;

        // When
        postService.deletePost(id);

        // Then
        verify(postRepository, times(1)).deleteById(id);
    }
}
