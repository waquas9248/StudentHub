package com.app.studenthub.service;

import com.app.studenthub.model.Group;
import com.app.studenthub.repository.GroupRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class GroupServiceTest {

    @MockBean
    private GroupRepository groupRepository;

    @Autowired
    private GroupService groupService;

    @Test
    void testGetAllGroups() {
        // Given
        Group group1 = new Group();
        Group group2 = new Group();
        when(groupRepository.findAll()).thenReturn(Arrays.asList(group1, group2));

        // When
        List<Group> groups = groupService.getAllGroups();

        // Then
        assertEquals(2, groups.size());
        verify(groupRepository, times(1)).findAll();
    }

    @Test
    void testGetGroupById() {
        // Given
        Group group = new Group();
        Long id = 1L;
        when(groupRepository.findById(id)).thenReturn(Optional.of(group));

        // When
        Optional<Group> result = groupService.getGroupById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(group, result.get());
        verify(groupRepository, times(1)).findById(id);
    }

    @Test
    void testCreateGroup() {
        // Given
        Group group = new Group();
        when(groupRepository.save(group)).thenReturn(group);

        // When
        Group createdGroup = groupService.createGroup(group);

        // Then
        assertNotNull(createdGroup);
        verify(groupRepository, times(1)).save(group);
    }

    @Test
    void testUpdateGroup() {
        // Given
        Long id = 1L;
        Group existingGroup = new Group();
        existingGroup.setName("Old Name");
        existingGroup.setBody("Old Body");

        Group updatedGroupDetails = new Group();
        updatedGroupDetails.setName("New Name");
        updatedGroupDetails.setBody("New Body");

        when(groupRepository.findById(id)).thenReturn(Optional.of(existingGroup));
        when(groupRepository.save(existingGroup)).thenReturn(existingGroup);

        // When
        Group updatedGroup = groupService.updateGroup(id, updatedGroupDetails);

        // Then
        assertNotNull(updatedGroup);
        assertEquals("New Name", updatedGroup.getName());
        assertEquals("New Body", updatedGroup.getBody());
        verify(groupRepository, times(1)).findById(id);
        verify(groupRepository, times(1)).save(existingGroup);
    }

    @Test
    void testDeleteGroup() {
        // Given
        Long id = 1L;

        // When
        groupService.deleteGroup(id);

        // Then
        verify(groupRepository, times(1)).deleteById(id);
    }
}
