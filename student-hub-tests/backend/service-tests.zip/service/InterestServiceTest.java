package com.app.studenthub.service;

import com.app.studenthub.model.Interest;
import com.app.studenthub.repository.InterestRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class InterestServiceTest {

    @MockBean
    private InterestRepository interestRepository;

    @Autowired
    private InterestService interestService;

    @Test
    void testGetAllInterests() {
        // Given
        Interest interest1 = new Interest();
        Interest interest2 = new Interest();
        when(interestRepository.findAll()).thenReturn(Arrays.asList(interest1, interest2));

        // When
        List<Interest> interests = interestService.getAllInterests();

        // Then
        assertEquals(2, interests.size());
        verify(interestRepository, times(1)).findAll();
    }

    @Test
    void testGetInterestById() {
        // Given
        Interest interest = new Interest();
        Long id = 1L;
        when(interestRepository.findById(id)).thenReturn(Optional.of(interest));

        // When
        Optional<Interest> result = interestService.getInterestById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(interest, result.get());
        verify(interestRepository, times(1)).findById(id);
    }

    @Test
    void testCreateInterest() {
        // Given
        Interest interest = new Interest();
        when(interestRepository.save(interest)).thenReturn(interest);

        // When
        Interest createdInterest = interestService.createInterest(interest);

        // Then
        assertNotNull(createdInterest);
        verify(interestRepository, times(1)).save(interest);
    }

    @Test
    void testUpdateInterest() {
        // Given
        Long id = 1L;
        Interest existingInterest = new Interest();
        existingInterest.setTitle("Old Title");
        
        Interest updatedInterestDetails = new Interest();
        updatedInterestDetails.setTitle("New Title");

        when(interestRepository.findById(id)).thenReturn(Optional.of(existingInterest));
        when(interestRepository.save(existingInterest)).thenReturn(existingInterest);

        // When
        Interest updatedInterest = interestService.updateInterest(id, updatedInterestDetails);

        // Then
        assertNotNull(updatedInterest);
        assertEquals("New Title", updatedInterest.getTitle());
        verify(interestRepository, times(1)).findById(id);
        verify(interestRepository, times(1)).save(existingInterest);
    }

    @Test
    void testDeleteInterest() {
        // Given
        Long id = 1L;

        // When
        interestService.deleteInterest(id);

        // Then
        verify(interestRepository, times(1)).deleteById(id);
    }
}
