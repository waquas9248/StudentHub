package com.app.studenthub.service;

import com.app.studenthub.model.Rating;
import com.app.studenthub.model.Outlet;
import com.app.studenthub.model.User;
import com.app.studenthub.repository.RatingRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class RatingServiceTest {

    @MockBean
    private RatingRepository ratingRepository;

    @Autowired
    private RatingService ratingService;

    @Test
    void testGetAllRatings() {
        // Given
        Rating rating1 = new Rating();
        Rating rating2 = new Rating();
        when(ratingRepository.findAll()).thenReturn(Arrays.asList(rating1, rating2));

        // When
        List<Rating> ratings = ratingService.getAllRatings();

        // Then
        assertEquals(2, ratings.size());
        verify(ratingRepository, times(1)).findAll();
    }

    @Test
    void testGetRatingById() {
        // Given
        Long id = 1L;
        Rating rating = new Rating();
        when(ratingRepository.findById(id)).thenReturn(Optional.of(rating));

        // When
        Optional<Rating> result = ratingService.getRatingById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(rating, result.get());
        verify(ratingRepository, times(1)).findById(id);
    }

    @Test
    void testGetAllRatingsByUserId() {
        // Given
        Long userId = 1L;
        Rating rating1 = new Rating();
        Rating rating2 = new Rating();
        when(ratingRepository.findAllByUser_Id(userId)).thenReturn(Arrays.asList(rating1, rating2));

        // When
        List<Rating> ratings = ratingService.getAllRatingsByUserId(userId);

        // Then
        assertEquals(2, ratings.size());
        verify(ratingRepository, times(1)).findAllByUser_Id(userId);
    }

    @Test
    void testGetAllRatingsByOutletId() {
        // Given
        Long outletId = 1L;
        Rating rating1 = new Rating();
        Rating rating2 = new Rating();
        when(ratingRepository.findAllByOutlet_Id(outletId)).thenReturn(Arrays.asList(rating1, rating2));

        // When
        List<Rating> ratings = ratingService.getAllRatingsByOutletId(outletId);

        // Then
        assertEquals(2, ratings.size());
        verify(ratingRepository, times(1)).findAllByOutlet_Id(outletId);
    }

    @Test
    void testCreateRating() {
        // Given
        Rating rating = new Rating();
        when(ratingRepository.save(rating)).thenReturn(rating);

        // When
        Rating createdRating = ratingService.createRating(rating);

        // Then
        assertNotNull(createdRating);
        assertEquals(rating, createdRating);
        verify(ratingRepository, times(1)).save(rating);
    }

    @Test
    void testUpdateRating() {
        // Given
        Long id = 1L;
        Rating existingRating = new Rating();
        existingRating.setRating(4.0F);
        existingRating.setBody("Old Body");
        existingRating.setCreatedAt(LocalDateTime.now());

        Outlet outlet = new Outlet();
        User user = new User();

        Rating updatedRatingDetails = new Rating();
        updatedRatingDetails.setOutlet(outlet);
        updatedRatingDetails.setUser(user);
        updatedRatingDetails.setRating(5.0F);
        updatedRatingDetails.setBody("New Body");
        updatedRatingDetails.setCreatedAt(LocalDateTime.now());

        when(ratingRepository.findById(id)).thenReturn(Optional.of(existingRating));
        when(ratingRepository.save(existingRating)).thenReturn(existingRating);

        // When
        Rating updatedRating = ratingService.updateRating(id, updatedRatingDetails);

        // Then
        assertNotNull(updatedRating);
        assertEquals(outlet, updatedRating.getOutlet());
        assertEquals(user, updatedRating.getUser());
        assertEquals(5.0F, updatedRating.getRating());
        assertEquals("New Body", updatedRating.getBody());
        verify(ratingRepository, times(1)).findById(id);
        verify(ratingRepository, times(1)).save(existingRating);
    }

    @Test
    void testDeleteRating() {
        // Given
        Long id = 1L;

        // When
        ratingService.deleteRating(id);

        // Then
        verify(ratingRepository, times(1)).deleteById(id);
    }
}
