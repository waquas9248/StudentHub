package com.app.studenthub.service;

import com.app.studenthub.model.Role;
import com.app.studenthub.repository.RoleRepository;
import com.app.studenthub.util.UserRole;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class RoleServiceTest {

    @MockBean
    private RoleRepository roleRepository;

    @Autowired
    private RoleService roleService;

    @Test
    void testGetAllRoles() {
        // Given
        Role role1 = new Role();
        Role role2 = new Role();
        when(roleRepository.findAll()).thenReturn(Arrays.asList(role1, role2));

        // When
        List<Role> roles = roleService.getAllRoles();

        // Then
        assertEquals(2, roles.size());
        verify(roleRepository, times(1)).findAll();
    }

    @Test
    void testGetRoleById() {
        // Given
        Long id = 1L;
        Role role = new Role();
        when(roleRepository.findById(id)).thenReturn(Optional.of(role));

        // When
        Optional<Role> result = roleService.getRoleById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(role, result.get());
        verify(roleRepository, times(1)).findById(id);
    }

    @Test
    void testGetAllRolesByType() {
        // Given
        UserRole type = UserRole.ADMIN;
        Role role1 = new Role();
        role1.setType(type);
        Role role2 = new Role();
        role2.setType(type);
        when(roleRepository.findAllByType(type)).thenReturn(Arrays.asList(role1, role2));

        // When
        List<Role> roles = roleService.getAllRolesByType(type);

        // Then
        assertEquals(2, roles.size());
        for (Role role : roles) {
            assertEquals(type, role.getType());
        }
        verify(roleRepository, times(1)).findAllByType(type);
    }

    @Test
    void testCreateRole() {
        // Given
        Role role = new Role();
        when(roleRepository.save(role)).thenReturn(role);

        // When
        Role createdRole = roleService.createRole(role);

        // Then
        assertNotNull(createdRole);
        assertEquals(role, createdRole);
        verify(roleRepository, times(1)).save(role);
    }

    @Test
    void testUpdateRole() {
        // Given
        Long id = 1L;
        Role existingRole = new Role();
        existingRole.setType(UserRole.USER);

        Role updatedRoleDetails = new Role();
        updatedRoleDetails.setType(UserRole.ADMIN);

        when(roleRepository.findById(id)).thenReturn(Optional.of(existingRole));
        when(roleRepository.save(existingRole)).thenReturn(existingRole);

        // When
        Role updatedRole = roleService.updateRole(id, updatedRoleDetails);

        // Then
        assertNotNull(updatedRole);
        assertEquals(UserRole.ADMIN, updatedRole.getType());
        verify(roleRepository, times(1)).findById(id);
        verify(roleRepository, times(1)).save(existingRole);
    }

    @Test
    void testDeleteRole() {
        // Given
        Long id = 1L;

        // When
        roleService.deleteRole(id);

        // Then
        verify(roleRepository, times(1)).deleteById(id);
    }
}
