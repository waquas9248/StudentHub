package com.app.studenthub.service;

import com.app.studenthub.model.Attendee;
import com.app.studenthub.repository.AttendeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class AttendeeServiceTest {

    @MockBean
    private AttendeeRepository attendeeRepository;

    @Autowired
    private AttendeeService attendeeService;

    @BeforeEach
    void setup() {
        // Setup code if needed
    }

    @Test
    void testGetAllAttendees() {
        // Given
        Attendee attendee1 = new Attendee();
        Attendee attendee2 = new Attendee();
        when(attendeeRepository.findAll()).thenReturn(Arrays.asList(attendee1, attendee2));

        // When
        List<Attendee> attendees = attendeeService.getAllAttendees();

        // Then
        assertEquals(2, attendees.size());
        verify(attendeeRepository, times(1)).findAll();
    }

    @Test
    void testGetAttendeeById() {
        // Given
        Attendee attendee = new Attendee();
        Long id = 1L;
        when(attendeeRepository.findById(id)).thenReturn(Optional.of(attendee));

        // When
        Optional<Attendee> result = attendeeService.getAttendeeById(id);

        // Then
        assertTrue(result.isPresent());
        assertEquals(attendee, result.get());
        verify(attendeeRepository, times(1)).findById(id);
    }

    @Test
    void testCreateAttendee() {
        // Given
        Attendee attendee = new Attendee();
        when(attendeeRepository.save(attendee)).thenReturn(attendee);

        // When
        Attendee createdAttendee = attendeeService.createAttendee(attendee);

        // Then
        assertNotNull(createdAttendee);
        verify(attendeeRepository, times(1)).save(attendee);
        assertNotNull(createdAttendee.getCreatedAt());
    }

    @Test
    void testDeleteAttendee() {
        // Given
        Long id = 1L;

        // When
        attendeeService.deleteAttendee(id);

        // Then
        verify(attendeeRepository, times(1)).deleteById(id);
    }

    @Test
    void testGetAttendeesByUserId() {
        // Given
        Long userId = 1L;
        Attendee attendee1 = new Attendee();
        Attendee attendee2 = new Attendee();
        when(attendeeRepository.findByUserId(userId)).thenReturn(Arrays.asList(attendee1, attendee2));

        // When
        List<Attendee> attendees = attendeeService.getAttendeesByUserId(userId);

        // Then
        assertNotNull(attendees);
        assertEquals(2, attendees.size());
        verify(attendeeRepository, times(1)).findByUserId(userId);
    }

    @Test
    void testGetAttendeesByEventId() {
        // Given
        Long eventId = 1L;
        Attendee attendee1 = new Attendee();
        Attendee attendee2 = new Attendee();
        when(attendeeRepository.findByEventId(eventId)).thenReturn(Arrays.asList(attendee1, attendee2));

        // When
        List<Attendee> attendees = attendeeService.getAttendeesByEventId(eventId);

        // Then
        assertNotNull(attendees);
        assertEquals(2, attendees.size());
        verify(attendeeRepository, times(1)).findByEventId(eventId);
    }
}

